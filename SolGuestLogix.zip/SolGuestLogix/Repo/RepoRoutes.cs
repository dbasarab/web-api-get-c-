﻿using Models;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Repo
{
    public class RepoRoutes
    {
        public async Task<Route[]> AllRoutes()
        {
            await Task.Yield();
            return new Route[] {
            new Route() { AirlineId = "AC", Origin = "YYZ", Destination= "JFK" },
            new Route() { AirlineId = "AC", Origin = "JFK", Destination= "YYZ" },
            new Route() { AirlineId = "AC", Origin = "LAX", Destination= "YVR" },
            new Route() { AirlineId = "AC", Origin = "YVR", Destination= "LAX" },
            new Route() { AirlineId = "UA", Origin = "LAX", Destination= "JFK" },
            new Route() { AirlineId = "UA", Origin = "JFK", Destination= "LAX" },
                };

            //comment the above and uncomment the bellow code to load from App_Data Routes.txt - a csv file
/*
            string appdatafolder = Path.Combine(HttpContext.Current.Request.PhysicalApplicationPath, "App_Data");

            var list = new List<Route>();
            using (var stream = new FileStream(Path.Combine(appdatafolder, "Routes.txt"), FileMode.Open, FileAccess.Read, FileShare.Read))
            using (var reader = new StreamReader(stream, Encoding.ASCII))
            {
                string line;
                while ((line = await reader.ReadLineAsync()) != null)
                {
                    var values = line.Split(',');
                    list.Add(new Route() { AirlineId = values[0], Origin = values[1], Destination = values[2] });
                }
            }

            return list.ToArray();
*/
        }

    }
}
