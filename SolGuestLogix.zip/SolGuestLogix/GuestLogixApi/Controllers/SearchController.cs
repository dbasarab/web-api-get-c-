﻿using Models;
using Repo;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace GuestLogixApi.Controllers
{
    public class SearchController : ApiController
    {
        private Route[] routes;
        private Airline[] airlines;
        private Airport[] airports;
        private string _origin;

        public async Task<IHttpActionResult> GetRoute(string origin, string destination)  
        {
            origin = origin.ToUpper();
            destination = destination.ToUpper();
            _origin = origin;
            var repoRoutes = new RepoRoutes();
            routes = await repoRoutes.AllRoutes();

            var repoAirlines = new RepoAirlines();
            airlines = repoAirlines.AllAirlines();

            var repoAirports = new RepoAirports();
            Airport[] airports = repoAirports.AllAirports();

            if (string.IsNullOrEmpty(origin) || !airports.Any(x => x.IATA3 == origin))
            {
                HttpResponseMessage message = new HttpResponseMessage(HttpStatusCode.InternalServerError);
                string s = "invalid origin";
                message.Content = new StringContent(s);
                //LogHandler.logger.Error(s);  //if we want to log locally using e.g. NLog

                throw new HttpResponseException(message);
            }

            if (string.IsNullOrEmpty(destination) || !airports.Any(x => x.IATA3 == destination))
            {
                HttpResponseMessage message = new HttpResponseMessage(HttpStatusCode.InternalServerError);
                string s = "invalid destination";
                message.Content = new StringContent(s);

                throw new HttpResponseException(message);
            }

            var route = getRoute(origin, destination);
            if (string.IsNullOrEmpty(route))
            {
                route = "no route";
            }

            return Ok(route);
        }

        private string result;

        private HashSet<int> hs = new HashSet<int>();

        private string getRoute(string origin, string destination)
        {
            if (routes.Any(x => x.Origin == origin && x.Destination == destination))
            {
                result += $"{origin}->{destination}";
                return result;
            }

            foreach(var r in routes)
            {
                if (r.Origin == origin)
                {
                    if (r.Destination == origin || r.Destination == _origin)
                        continue;

                    if (hs.Contains(origin.GetHashCode() + destination.GetHashCode()))  //do not run over the same data
                        continue;

                    hs.Add(origin.GetHashCode() + destination.GetHashCode());

                    result += $"{origin}->";

                    return getRoute(r.Destination, destination);  //recursion
                }
            }

            return null;
        }
    }
}
