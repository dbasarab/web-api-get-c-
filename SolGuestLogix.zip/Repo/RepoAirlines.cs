﻿using Models;

namespace Repo
{
    public class RepoAirlines
    {
        public Airline[] AllAirlines()
        {           
            return new Airline[] {
        new Airline() { Name = "Air Canada", TwoDigitCode = "AC", ThreeDigitCode= "ACA", Country = "Canada" },
        //new Airline() { Name = "China Southern Airlines", TwoDigitCode = "CZ", ThreeDigitCode= "CSN", Country = "China" },
        //new Airline() { Name = "Southwest Airlines", TwoDigitCode = "WN", ThreeDigitCode= "SWA", Country = "United States" },
        //new Airline() { Name = "Turkish Airlines", TwoDigitCode = "TK", ThreeDigitCode= "THY", Country = "Turkey" },
        new Airline() { Name = "United Airlines", TwoDigitCode = "UA", ThreeDigitCode= "UAL", Country = "United States" },
//        new Airline() { Name = "WestJet", TwoDigitCode = "WS", ThreeDigitCode= "WJA", Country = "Canada" },
            };
        }

    }

}
