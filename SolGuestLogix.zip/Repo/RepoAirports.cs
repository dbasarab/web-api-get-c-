﻿using Models;

namespace Repo
{
    public class RepoAirports
    {
        public Airport[] AllAirports()
        {
            return new Airport[] {
        //new Airport() { Name = "Goroka Airport", City = "Goroka", Country= "Papua New Guinea", IATA3 = "GKA", Latitude=-6.081689835, Longitude=145.3919983 },
        new Airport() { Name = "John F Kennedy International Airport", City = "New York", Country= "United States", IATA3 = "JFK", Latitude=40.63980103, Longitude=-73.77890015 },
        new Airport() { Name = "Lester B. Pearson International Airport", City = "Toronto", Country= "Canada", IATA3 = "YYZ", Latitude=43.67720032, Longitude=-79.63059998 },
        new Airport() { Name = "Los Angeles International Airport", City = "Los Angeles", Country= "United States", IATA3 = "LAX", Latitude=33.94250107, Longitude=-118.4079971 },
        new Airport() { Name = "Vancouver International Airport", City = "Vancouver", Country= "Canada", IATA3 = "YVR", Latitude=49.19390106, Longitude=-123.1839981 },
        new Airport() { Name = "Chicago O'Hare International Airport", City = "Chicago", Country= "United States", IATA3 = "ORD", Latitude=41.97859955, Longitude=-87.90480042 },
            };
        }


    }
}
